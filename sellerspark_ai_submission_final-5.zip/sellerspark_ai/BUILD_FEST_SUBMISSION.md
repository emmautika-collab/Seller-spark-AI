# SellerSpark AI — BuildFest 2026 Submission & Evidence Pack

## Track
**Track 2: AI for Content & Creativity**

## Primary case study
**Case Study 1 — AI Content Generator**

SellerSpark AI turns a small-business brief into an editable marketing draft. The user remains responsible for review, verification, approval, saving, and export.

## Core workflow
1. Enter brief, audience, platform, tone, and goal.
2. Generate with AI.
3. Inspect fact-verification flags.
4. Edit the draft as a human reviewer.
5. Regenerate when the first angle is not right.
6. Approve the reviewed version.
7. Save to local history.
8. Export the draft and optional evidence JSON.

## Four assistant modes
- **AI Content Generator (core):** general marketing content.
- **Social Media Assistant:** platform-ready hook, body, CTA, hashtags.
- **Scriptwriting Assistant:** hook, beats, on-screen text, CTA.
- **Branding Assistant:** positioning, promise, voice, visual direction, taglines.

## Responsible AI design
SellerSpark does not auto-publish AI output. It surfaces common risk patterns—numeric claims, superlatives, health/safety language, and price/offer language—for human verification. These are **verification flags, not proof that a claim is false**.

## Real AI + demo resilience
When `OPENAI_API_KEY` is configured, the server calls the OpenAI Responses API. The browser never receives the secret key. Without a key, the same workflow runs in deterministic demo mode for rehearsal and judging continuity.

## Run
```bash
npm install
cp .env.example .env
# Add OPENAI_API_KEY to .env for live AI
npm start
```
Open `http://localhost:3000`.

## Test
```bash
npm test
```
The test suite covers claim flags, all four assistant modes, health, generation, and input validation.

## Judge evidence checklist
- [ ] Branded home screen
- [ ] Live AI status visible
- [ ] AI-generated draft
- [ ] Human edits draft
- [ ] Fact-verification flag visible
- [ ] Regeneration produces a new version
- [ ] Human approval state visible
- [ ] Saved item appears in history
- [ ] `.txt` export works
- [ ] Evidence JSON export works
- [ ] All four modes demonstrated
- [ ] `npm test` passes

## 90-second demo script
**0–15s:** “Small businesses often have the idea but not the time or confidence to turn it into usable content. SellerSpark is a creative co-pilot that keeps the human in control.”

**15–35s:** Enter a bakery launch brief and generate the core content. Point to the AI status.

**35–50s:** Edit one sentence. Show the fact-verification flags and explain that they prompt checking rather than automatic publication.

**50–65s:** Regenerate to show a different creative direction.

**65–78s:** Approve, save, export, and open the evidence JSON if needed.

**78–90s:** Switch through Social, Scriptwriting, and Branding. Close with: “SellerSpark turns AI output into reviewed, usable business content.”

## Technical architecture
`Browser UI → Node server → OpenAI Responses API → editable draft → verification flags → human approval → local history/export`

## Submission hygiene
- No API key is stored in the repository.
- `.env` is ignored by Git.
- Demo mode makes the interface testable without credentials.
- The project is dependency-light and can be run with Node.js 20+.
